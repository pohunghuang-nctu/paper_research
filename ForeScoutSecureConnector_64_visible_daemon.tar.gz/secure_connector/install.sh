#!/bin/bash
echo "############ installation process ############"
dir_name=`dirname "$0"`
cd $dir_name
SC_PATH=/usr/lib/forescout
SC_Installed=/usr/lib/forescout/daemon
prefix="$0 :"
app_type=`cat .config/com.forescout.secureconnector.json | grep -Po '(?<="app_type": ")[^"]*' `
if [ "$app_type" = "dissolvable" ]
then
	echo "dissolvable installation..."
	SC_PATH=$PWD/forescout
fi
LOG_FILE=$SC_PATH/installation.log
#added
if [ -d $SC_Installed ]
then
    echo "SecureConnector is already installed on this host at - $SC_PATH.\n please uninstall the SC before you install new SC, or use upgrade action " | tee -a ${LOG_FILE}
    exit 1
fi
#added
sc_processes=`ps auxww  | grep -v grep | egrep "ForeScoutSecureConnector.*" | awk '{print $2}'`
if [ "${sc_processes}" != "" ]
then
    echo "SecureConnector already running on your host. Please close the process and try to install again"
    exit 1
fi

#Create SC_PATH
mkdir -p $SC_PATH
echo "$prefix Package file - $PWD/forescout_sc.tar.tbz" | tee -a ${LOG_FILE}
echo "$prefix Installation path - $SC_PATH" | tee -a ${LOG_FILE}
echo "$prefix Uncompressing Forescout SecureConnector files..." | tee -a ${LOG_FILE}
#Required basic packeges verification:

flavorlinux=$(hostnamectl | grep "Operating" | awk {'print $3'})
if [[ "$flavorlinux" == "CentOS" ]] || [[ "$flavorlinux" == "Red" ]] || [[ "$flavorlinux" == "openSUSE" ]]
then
  bzip2=`rpm -qa |grep bzip2-1`
  wget=`rpm -qa |grep wget`

  if [[ "$bzip2" == "" ]] || [[ "$wget" == "" ]]
  then
    printf "The following packages are required in order to install Forescout SecureConnector:\n"
    printf "bzip2\nwget\n"
    printf "Usage: yum install <package_name>\n"
    exit 1
  fi
elif [[ "$flavorlinux" == "Ubuntu" ]] || [[ "$flavorlinux" == "Debian" ]] || [[ "$flavorlinux" == "Kali" ]]
then
  bzip2_=`dpkg -l |grep bzip2`
  wget_=`dpkg -l|grep wget`
  if [[ "$bzip2_" == "" ]] || [[ "$wget_" == "" ]]
  then
    printf "The following packages are required in order to install Forescout SecureConnector:\n"
    printf "bzip2\nwget\n"
    printf "Usage: dpkg -i <package_name>\n"
    exit 1
  fi

fi


tar -xjf $PWD/forescout_sc.tar.tbz -C $SC_PATH --strip-components=1 --no-same-owner
echo "$prefix Files uncompressed successfully!" | tee -a ${LOG_FILE}
echo "$prefix Copying configuration file..." | tee -a ${LOG_FILE}
cp .config/com.forescout.secureconnector.json $SC_PATH/bin/
echo "$prefix Copying certificate..." | tee -a ${LOG_FILE}
cp .config/server-cert.pem $SC_PATH/bin/
echo "$prefix Running set_secureconnector_configuration.sh script" | tee -a ${LOG_FILE}
if [ "$app_type" = "daemon" ]
then
	echo "$prefix Set root permissions to $SC_PATH..." | tee -a ${LOG_FILE}
	chmod -R 755 $SC_PATH
fi
bash $SC_PATH/set_secureconnector_configuration.sh $SC_PATH

echo "$prefix Done!" | tee -a ${LOG_FILE}
