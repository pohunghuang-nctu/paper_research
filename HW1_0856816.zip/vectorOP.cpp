#include "PPintrin.h"

// implementation of absSerial(), but it is vectorized using PP intrinsics
void absVector(float *values, float *output, int N)
{
  __pp_vec_float x;
  __pp_vec_float result;
  __pp_vec_float zero = _pp_vset_float(0.f);
  __pp_mask maskAll, maskIsNegative, maskIsNotNegative;

  //  Note: Take a careful look at this loop indexing.  This example
  //  code is not guaranteed to work when (N % VECTOR_WIDTH) != 0.
  //  Why is that the case?

  //find nearest integral value of N wrt VECTOR_WIDTH
  int NnearestInt = (N - (N % VECTOR_WIDTH));

  //for (int i = 0; i < N; i += VECTOR_WIDTH)
  for (int i = 0; i < NnearestInt; i += VECTOR_WIDTH)
  {

    // All ones
    maskAll = _pp_init_ones();

    // All zeros
    maskIsNegative = _pp_init_ones(0);

    // Load vector of values from contiguous memory addresses
    _pp_vload_float(x, values + i, maskAll); // x = values[i];

    // Set mask according to predicate
    _pp_vlt_float(maskIsNegative, x, zero, maskAll); // if (x < 0) {

    // Execute instruction using mask ("if" clause)
    _pp_vsub_float(result, zero, x, maskIsNegative); //   output[i] = -x;

    // Inverse maskIsNegative to generate "else" mask
    maskIsNotNegative = _pp_mask_not(maskIsNegative); // } else {

    // Execute instruction ("else" clause)
    _pp_vload_float(result, values + i, maskIsNotNegative); //   output[i] = x; }

    // Write results back to memory
    _pp_vstore_float(output + i, result, maskAll);
  }

  // processing edge cases
  for (int i = NnearestInt; i < N; i++)
  {
    float x = values[i];
    if (x < 0)
    {
      output[i] = -x;
    }
    else
    {
      output[i] = x;
    }
  }
}
// accepts an array of values and an array of exponents
//
// For each element, compute values[i]^exponents[i] and clamp value to
// 9.999.  Store result in output.
void clampedExpVector(float *values, int *exponents, float *output, int N)
{
    __pp_vec_int zero ;
    zero = _pp_vset_int(0);
    __pp_vec_int one;
    one = _pp_vset_int(1);
    __pp_vec_float nearestTen;
    nearestTen = _pp_vset_float(9.999999f);
    //printf("N = %d, VECTOR_WIDTH = %d\n", N, VECTOR_WIDTH);
    //fflush(stdout);
    for (int i = 0; i < N; i += VECTOR_WIDTH)
    {
      __pp_mask valueMask = _pp_init_ones();
      __pp_vec_float result = _pp_vset_float(1.f);
      //printf("init result with 1.f, start at %d\n", i);
      //fflush(stdout);
      if (i + VECTOR_WIDTH > N) {
        int residual = N - i;
        valueMask = _pp_init_ones(residual);
      } else {
        valueMask = _pp_init_ones();
      }
      __pp_vec_float v;
      _pp_vload_float(v, values + i, valueMask);

      __pp_vec_int exp;
      _pp_vload_int(exp, exponents + i, valueMask);

      __pp_mask gtZeroMask;
      _pp_vgt_int(gtZeroMask, exp, zero, valueMask);
      // Count the number of lanes which exp greater than 0
      int numGtZero = _pp_cntbits(gtZeroMask);
      // Loop until no any lanes of exp greater than 0
      int loopCounter = 0;
      while (numGtZero > 0 && loopCounter < 10)
      {
        //print_pp_vec_int(exp);
        //printf("numGtZero = %d\n", numGtZero);
        fflush(stdout);
        // bitwise mask which is the intersection between "gtZeroMask" and "valueMask"
        __pp_mask lessThanTenMask; 
        // only result < 9.99999f will be multiply by v
        //printf("before = ");
        //print_pp_vec_float(result);
        _pp_vlt_float(lessThanTenMask, result, nearestTen, valueMask);
        __pp_mask tmpMask = _pp_mask_and(gtZeroMask, valueMask);
        tmpMask = _pp_mask_and(tmpMask, lessThanTenMask);
        //tmpMask = valueMask and gtZeroMask(exp) and lessThanTenMask
        /*
        printf("lessThanTenMask = ");
        print_pp_mask(lessThanTenMask);
        printf("gtZeroMask = ");
        print_pp_mask(gtZeroMask);
        printf("tmpMask = ");
        print_pp_mask(tmpMask);
        fflush(stdout);
        */
        _pp_vmult_float(result, result, v, tmpMask);
        __pp_mask gtTenMask;
        // if result > 9.99999f will be set to 9.99999f       
        _pp_vgt_float(gtTenMask, result, nearestTen, valueMask);
        _pp_vset_float(result, 9.999999f, gtTenMask);
        //printf("after = ");
        //print_pp_vec_float(result);
        //fflush(stdout);
        _pp_vlt_float(lessThanTenMask, result, nearestTen, valueMask);
        // each lane of exp minus 1
        _pp_vsub_int(exp, exp, one, tmpMask);
        _pp_vgt_int(gtZeroMask, exp, zero, valueMask);
        gtZeroMask = _pp_mask_and(gtZeroMask, lessThanTenMask);
        //printf("lessThanTenMask = ");
        //print_pp_mask(lessThanTenMask);
        //printf("gtZeroMask = ");
        //print_pp_mask(gtZeroMask);
        //printf("\n");
        //fflush(stdout);
        numGtZero = _pp_cntbits(gtZeroMask);
        ++loopCounter;
      }
      // store result to output
      _pp_vstore_float(output + i, result, valueMask);
    }
}

// returns the sum of all elements in values
// You can assume N is a multiple of VECTOR_WIDTH
// You can assume VECTOR_WIDTH is a power of 2
float arraySumVector(float *values, int N)
{
  __pp_vec_float sum = _pp_vset_float(0.0f);
  int num_vec = N / VECTOR_WIDTH;
  __pp_mask valueMask = _pp_init_ones();

  for (int i = 0; i < num_vec; i++) {
    __pp_vec_float vec;
    _pp_vload_float(vec, values + i * VECTOR_WIDTH, valueMask);
    _pp_vadd_float(sum, sum, vec, valueMask);
  }

  float result = 0.0f;
  // Reduce sum using _pp_hadd_float()
  int vector_width = VECTOR_WIDTH;
  while (vector_width > 1) {
    _pp_hadd_float(sum, sum);
    vector_width /= 2;
    _pp_interleave_float(sum, sum);
  }
  float sum_vec[VECTOR_WIDTH];
  _pp_vstore_float(sum_vec, sum, valueMask);
  result = sum_vec[0];
  return result;
}