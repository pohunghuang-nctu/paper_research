#include "page_rank.h"

#include <stdlib.h>
#include <cstring>
#include <cmath>
#include <omp.h>
#include <utility>
#include <iostream>

#include "../common/CycleTimer.h"
#include "../common/graph.h"

void pageRank(Graph g, double *solution, double damping, double convergence)
{
  int numNodes = num_nodes(g);
  double *solution_address = solution;
  double equal_prob = 1.0 / numNodes;
  for (int i = 0; i < numNodes; ++i)
  {
    solution[i] = equal_prob;
  }

  double *score_new = (double *)malloc(numNodes * sizeof(double));
  bool converged = false;

  while (!converged)
  {
    double no_outgoing_sum = 0.0;

    #pragma omp parallel
    {
      #pragma omp for reduction(+:no_outgoing_sum)
      for (int vi = 0; vi < numNodes; ++vi)
      {
        score_new[vi] = 0.0;
        for (const Vertex *iter = incoming_begin(g, vi); iter != incoming_end(g, vi); ++iter)
        {
          int vj = *iter;
          score_new[vi] += solution[vj] / outgoing_size(g, vj);
        }
        score_new[vi] = (damping * score_new[vi]) + (1.0 - damping) / numNodes;

        if (outgoing_size(g, vi) == 0)
        {
          no_outgoing_sum += solution[vi];
        }
      }
    }

    no_outgoing_sum *= damping / numNodes;

    double global_diff = 0.0;

    #pragma omp parallel for reduction(+:global_diff)
    for (int vi = 0; vi < numNodes; ++vi)
    {
      score_new[vi] += no_outgoing_sum;
      global_diff += std::abs(score_new[vi] - solution[vi]);
    }

    converged = (global_diff < convergence);

    std::swap(solution, score_new);
  }
  //std::cout << "To be freed address: " << score_new << std::endl;
  if (solution == solution_address) {
    free(score_new);
  } else {
    std::memcpy(solution_address, solution, numNodes * sizeof(double));
    free(solution);    
  }
}
