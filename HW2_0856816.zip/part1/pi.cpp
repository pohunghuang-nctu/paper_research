#include <iostream>
#include <ctime>
#include <cstdlib>
#include <pthread.h>
#include <immintrin.h>
#include <random>

using namespace std;

struct ThreadData {
    long long int tosses;
    long long int number_in_circle;
    unsigned int seed;
};

int count_set_bits(int mask) {
    return __builtin_popcount(mask);
}

void *monte_carlo(void *arg) {
    ThreadData *data = (ThreadData *)arg;
    long long int in_circle = 0;
    data->number_in_circle = 0;
    
    std::mt19937 rng(data->seed);
    std::uniform_real_distribution<float> dist(-1.0, 1.0);

    __m256 x, y, dist_squared;
    const __m256 one = _mm256_set1_ps(1.0f);

    for (long long int toss = 0; toss < data->tosses; toss += 8) {
        x = _mm256_set_ps(dist(rng), dist(rng), dist(rng), dist(rng),
                         dist(rng), dist(rng), dist(rng), dist(rng));
        y = _mm256_set_ps(dist(rng), dist(rng), dist(rng), dist(rng),
                         dist(rng), dist(rng), dist(rng), dist(rng));
        dist_squared = _mm256_add_ps(_mm256_mul_ps(x, x), _mm256_mul_ps(y, y));
        in_circle = count_set_bits(_mm256_movemask_ps(_mm256_cmp_ps(dist_squared, one, _CMP_LT_OS)));
        data->number_in_circle += in_circle;
    }

    pthread_exit(nullptr);
}

int main(int argc, char *argv[]) {
    const int number_of_threads = atoi(argv[1]);
    const long long int number_of_tosses = atoll(argv[2]);
    long long int number_in_circle = 0;
    pthread_t threads[number_of_threads];
    ThreadData thread_data[number_of_threads];

    unsigned int seed = time(NULL);

    for (int i = 0; i < number_of_threads; ++i) {
        thread_data[i].tosses = number_of_tosses / number_of_threads;
        thread_data[i].seed = seed + i;
        pthread_create(&threads[i], nullptr, monte_carlo, (void *)&thread_data[i]);
    }

    for (int i = 0; i < number_of_threads; ++i) {
        pthread_join(threads[i], nullptr);
        number_in_circle += thread_data[i].number_in_circle;
    }

    double pi_estimate = 4.0 * number_in_circle / number_of_tosses;
    cout << pi_estimate << endl;
    return 0;
}
