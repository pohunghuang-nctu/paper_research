#include <stdio.h>
#include <thread>
#include <cmath>
#include "CycleTimer.h"

typedef struct
{
    float x0, x1;
    float y0, y1;
    int width;
    int height;
    int maxIterations;
    int *output;
    int threadId;
    int numThreads;
} WorkerArgs;

extern void mandelbrotSerial(
    float x0, float y0, float x1, float y1,
    int width, int height,
    int startRow, int numRows,
    int maxIterations,
    int output[]);

void mandelbrotPartial(
    float x0, float y0, float x1, float y1,
    int width, int height,
    int startRow, int numRows,
    int maxIterations,
    int output[])
{
    mandelbrotSerial(x0, y0, x1, y1, width, height, startRow, numRows, maxIterations, output);
}
//
// workerThreadStart --
//
// Thread entrypoint.

/* The old version, cut total rows into N continuous parts, and each thread is responsible for one part.
 
void workerThreadStart(WorkerArgs *const args)
{
    int numRows = ceil(args->height / (float)args->numThreads);
    int startRow = args->threadId * numRows; 
    int endRow = startRow + numRows;
    if (endRow > args->height)
    {
        endRow = args->height;
    }
    numRows = endRow - startRow;
    printf("Entering thread %d, number of rows:%d\n", args->threadId, numRows);
    // Start measuring time for this thread
    double startTime = CycleTimer::currentSeconds();

    mandelbrotPartial(args->x0, args->y0, args->x1, args->y1, args->width, args->height, startRow, numRows, args->maxIterations, args->output);

    // Stop measuring time and calculate elapsed time
    double endTime = CycleTimer::currentSeconds();
    double elapsedTime = endTime - startTime;

    printf("Thread %d finished. Execution time: %.3f seconds.\n", args->threadId, elapsedTime);
}
*/
///* The new version, by round robin, each row is assigned to a thread, and each thread is responsible for all assigned rows.
void workerThreadStart(WorkerArgs *const args)
{
    printf("Entering thread %d\n", args->threadId);

    // int numRowsPerThread = ceil(args->height / (float)args->numThreads);
    //int startRow = args->threadId * numRowsPerThread;
    int startRow = args->threadId;
    // Start measuring time for this thread
    double startTime = CycleTimer::currentSeconds();

    for (int row = startRow; row < args->height; row += args->numThreads)
    {
        int endRow = row + 1;
        mandelbrotPartial(args->x0, args->y0, args->x1, args->y1, args->width, args->height, row, endRow - row, args->maxIterations, args->output);
    }

    // Stop measuring time and calculate elapsed time
    double endTime = CycleTimer::currentSeconds();
    double elapsedTime = endTime - startTime;

    printf("Thread %d finished. Execution time: %.3f seconds.\n", args->threadId, elapsedTime);
}
//*/
//
// MandelbrotThread --
//
// Multi-threaded implementation of mandelbrot set image generation.
// Threads of execution are created by spawning std::threads.
void mandelbrotThread(
    int numThreads,
    float x0, float y0, float x1, float y1,
    int width, int height,
    int maxIterations, int output[])
{
    static constexpr int MAX_THREADS = 32;

    if (numThreads > MAX_THREADS)
    {
        fprintf(stderr, "Error: Max allowed threads is %d\n", MAX_THREADS);
        exit(1);
    }

    // Creates thread objects that do not yet represent a thread.
    std::thread workers[MAX_THREADS];
    WorkerArgs args[MAX_THREADS];

    for (int i = 0; i < numThreads; i++)
    {
        // TODO FOR PP STUDENTS: You may or may not wish to modify
        // the per-thread arguments here.  The code below copies the
        // same arguments for each thread
        args[i].x0 = x0;
        args[i].y0 = y0;
        args[i].x1 = x1;
        args[i].y1 = y1;
        args[i].width = width;
        args[i].height = height;
        args[i].maxIterations = maxIterations;
        args[i].numThreads = numThreads;
        args[i].output = output;

        args[i].threadId = i;
    }

    // Spawn the worker threads.  Note that only numThreads-1 std::threads
    // are created and the main application thread is used as a worker
    // as well.
    for (int i = 1; i < numThreads; i++)
    {
        workers[i] = std::thread(workerThreadStart, &args[i]);
    }

    workerThreadStart(&args[0]);

    // join worker threads
    for (int i = 1; i < numThreads; i++)
    {
        workers[i].join();
    }
}
