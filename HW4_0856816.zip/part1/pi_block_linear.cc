#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#include <unistd.h>
//#include <immintrin.h>
#include <random>
#include <cmath>
//#include <avxintrin.h>


int count_set_bits(int mask) {
    return __builtin_popcount(mask);
}

int main(int argc, char **argv)
{
    // --- DON'T TOUCH ---
    MPI_Init(&argc, &argv);
    double start_time = MPI_Wtime();
    double pi_result;
    long long int tosses = atoi(argv[1]);
    int world_rank, world_size;
    // ---
    // Initialize MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);

    // Calculate the number of iterations per process
    long long int iter_per_process = tosses / world_size;

    // Seed the random number generator with the rank of each process
    //srand(time(NULL) * world_rank * getpid());
    std::mt19937 rng(time(NULL) * world_rank * getpid());
    std::uniform_real_distribution<float> dist(-1.0, 1.0);

    long long int local_count = 0;
    // __m256 x, y, dist_squared;
    // const __m256 one = _mm256_set_ps(1.0f, 1.0f, 1.0f, 1.0f, 
    //                                  1.0f, 1.0f, 1.0f, 1.0f);
    double loop_start_time = MPI_Wtime();
    for (long long int i = 0; i < iter_per_process; i++) {
    //for (long long int toss = 0; toss < iter_per_process; toss += 8) {
        float x = (float)dist(rng);
        float y = (float)dist(rng);
        // long long in_circle = 0;
        // x = _mm256_set_ps(dist(rng), dist(rng), dist(rng), dist(rng),
        //                  dist(rng), dist(rng), dist(rng), dist(rng));
        // y = _mm256_set_ps(dist(rng), dist(rng), dist(rng), dist(rng),
        //                  dist(rng), dist(rng), dist(rng), dist(rng));
        // dist_squared = _mm256_add_ps(_mm256_mul_ps(x, x), _mm256_mul_ps(y, y));
        // in_circle = count_set_bits(_mm256_movemask_ps(_mm256_cmp_ps(dist_squared, one, _CMP_LT_OS)));
        //local_count += in_circle;
        if ((x * x + y * y )<= 1.0f)
        {
            local_count++;
        }
    }
    double loop_end_time = MPI_Wtime();
    printf("Rank %d finished calculating in %lf secs.\n", world_rank, loop_end_time - loop_start_time);
    if (world_rank > 0)
    {
        MPI_Send(&local_count, 1, MPI_LONG_LONG_INT, 0, 0, MPI_COMM_WORLD);
    }
    else if (world_rank == 0)
    {
        // Master receives local_count from workers
        long long int temp_count;
        for (int i = 1; i < world_size; i++)
        {
            //MPI_Recv(&temp_count, 1, MPI_LONG_LONG_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            MPI_Recv(&temp_count, 1, MPI_LONG_LONG_INT, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            printf("Rank %d received %lld from rank %d\n", world_rank, temp_count, i);
            local_count += temp_count;
        }
    }

    if (world_rank == 0)
    {
        // Calculate the final PI result
        pi_result = (double)local_count / (double)tosses * 4.0;

        // --- DON'T TOUCH ---
        double end_time = MPI_Wtime();
        printf("%lf\n", pi_result);
        printf("MPI running time: %lf Seconds\n", end_time - start_time);
        // ---
    }

    MPI_Finalize();
    return 0;
}
