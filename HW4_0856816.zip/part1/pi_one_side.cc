#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#include <unistd.h>
#include <random>
#include <cmath>

int main(int argc, char **argv)
{
    // --- DON'T TOUCH ---
    MPI_Init(&argc, &argv);
    double start_time = MPI_Wtime();
    double pi_result;
    long long int tosses = atoi(argv[1]);
    int world_rank, world_size;
    // ---

    MPI_Win win;

    // Initialize MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);

    // Calculate the number of iterations per process
    long long int iter_per_process = tosses / world_size;

    // Seed the random number generator with the rank of each process
    std::mt19937 rng(time(NULL) * world_rank * getpid());
    //std::minstd_rand rng(time(NULL) * world_rank * getpid());
    //std::random_device rng(time(NULL) * world_rank * getpid());
    std::uniform_real_distribution<float> dist(-1.0, 1.0);

    long long int local_count = 0;

    for (long long int i = 0; i < iter_per_process; i++)
    {
        float x = (float)dist(rng);
        float y = (float)dist(rng);

        if (x * x + y * y <= 1.0)
        {
            local_count++;
        }
    }

    if (world_rank == 0)
    {
        // Master
        long long int* counts;
        MPI_Alloc_mem(world_size * sizeof(long long int), MPI_INFO_NULL, &counts);

        MPI_Win_create(counts, world_size * sizeof(long long int), sizeof(long long int), MPI_INFO_NULL, MPI_COMM_WORLD, &win);

        MPI_Win_lock(MPI_LOCK_SHARED, 0, 0, win);
        MPI_Put(&local_count, 1, MPI_LONG_LONG_INT, 0, world_rank, 1, MPI_LONG_LONG_INT, win);
        MPI_Win_unlock(0, win);

        MPI_Barrier(MPI_COMM_WORLD);

        long long int total_count = 0;
        for (int i = 0; i < world_size; i++)
        {
            total_count += counts[i];
        }

        // Calculate the final PI result
        pi_result = (double)total_count / (double)tosses * 4.0;

        // Free the allocated memory
        MPI_Free_mem(counts);
    }
    else
    {
        // Workers
        MPI_Win_create(NULL, 0, 1, MPI_INFO_NULL, MPI_COMM_WORLD, &win);

        MPI_Win_lock(MPI_LOCK_SHARED, 0, 0, win);
        MPI_Put(&local_count, 1, MPI_LONG_LONG_INT, 0, world_rank, 1, MPI_LONG_LONG_INT, win);
        MPI_Win_unlock(0, win);

        MPI_Barrier(MPI_COMM_WORLD);
    }

    MPI_Win_free(&win);

    if (world_rank == 0)
    {

        // --- DON'T TOUCH ---
        double end_time = MPI_Wtime();
        printf("%lf\n", pi_result);
        printf("MPI running time: %lf Seconds\n", end_time - start_time);
        // ---
    }
    
    MPI_Finalize();
    return 0;
}