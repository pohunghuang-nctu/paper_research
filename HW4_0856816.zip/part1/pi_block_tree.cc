#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#include <unistd.h>
#include <random>
#include <cmath>

int main(int argc, char **argv)
{
    // --- DON'T TOUCH ---
    MPI_Init(&argc, &argv);
    double start_time = MPI_Wtime();
    double pi_result;
    long long int tosses = atoi(argv[1]);
    int world_rank, world_size;
    // ---

    // TODO: MPI init
    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);

    long long int iter_per_process = tosses / world_size;
    if (world_rank == 0) {
        //printf("iter_per_process: %lld\n", iter_per_process);
    }
    // Seed the random number generator with the rank of each process
    std::mt19937 rng(time(NULL) * world_rank * getpid());
    std::uniform_real_distribution<float> dist(-1.0, 1.0);
    //srand(time(NULL) * world_rank * getpid());
    //srand(time(NULL) * world_rank);

    long long int local_count = 0;
    double loop_start_time = MPI_Wtime();
    for (long long int i = 0; i < iter_per_process; i++)
    {
        //float x = (float)rand() / (float)RAND_MAX * 2.0f - 1.0f;
        //float y = (float)rand() / (float)RAND_MAX * 2.0f - 1.0f;
        float x = (float)dist(rng);
        float y = (float)dist(rng);

        if ((x * x + y * y )<= 1.0f)
        {
            local_count++;
        }
    }
    double loop_end_time = MPI_Wtime();
    //printf("Rank %d finished calculating in %lf secs.\n", world_rank, loop_end_time - loop_start_time); 
    //printf("rank: %d -- local_count: %lld\n", world_rank, local_count);  
    // TODO: binary tree redunction
    int depth = 1;
    while ((1 << depth) <= world_size)
    {
        int base = 1 << depth - 1;
        //printf("round: %d, branch width: %d\n", depth, int(pow(2, depth)));
        if (world_rank % base != 0) {
            //printf("rank: %d -- not my business this round\n", world_rank);
        } else {
            if ( (world_rank / base) % 2 == 1) {
                // I'm the sender, send to my partner
                int partner = world_rank - base;
                //printf("I am rank: %d -- send to %d, my local count:%lld\n", world_rank, partner, local_count);
                MPI_Send(&local_count, 1, MPI_LONG_LONG_INT, partner, 0, MPI_COMM_WORLD);
            } else {
                int partner = world_rank + base;
                if (partner < world_size) {
                    //printf("I am rank: %d -- recv from %d\n", world_rank, partner);
                    long long int recv_count;
                    MPI_Recv(&recv_count, 1, MPI_LONG_LONG_INT, partner , 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                    local_count += recv_count;
                } else {
                    //printf("I am rank: %d -- no partner\n", world_rank);
                }
            }
        }
        depth += 1;
        MPI_Barrier(MPI_COMM_WORLD);
    }

    if (world_rank == 0)
    {
        // TODO: PI result

        // --- DON'T TOUCH ---
        pi_result = ((double)local_count / (double)tosses) * 4.0;
        double end_time = MPI_Wtime();
        printf("%lf\n", pi_result);
        printf("MPI running time: %lf Seconds\n", end_time - start_time);
        // ---
    }

    MPI_Finalize();
    return 0;
}
