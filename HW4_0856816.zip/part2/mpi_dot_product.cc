// mpi_dot_product.cc
#include <mpi.h>
#include <cstdio>
#include <cstdlib>

void construct_matrices(int *n_ptr, int *m_ptr, int *l_ptr, int **a_mat_ptr, int **b_mat_ptr) {
    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    if (rank == 0) {
        int n_read = scanf("%d %d %d", n_ptr, m_ptr, l_ptr);
        (void)n_read;
        *a_mat_ptr = (int *)malloc((*n_ptr) * (*m_ptr) * sizeof(int));
        // transpose b_mat for better space locality.
        // but for malloc, it's still a continuous memory space.        
        *b_mat_ptr = (int *)malloc((*m_ptr) * (*l_ptr) * sizeof(int));

        
        for (int i = 0; i < (*n_ptr) * (*m_ptr); i++) {
            int a_read = scanf("%d", &(*a_mat_ptr)[i]);
            (void)a_read;
        }

        for (int i = 0; i < (*m_ptr) * (*l_ptr); i++) {
            // position after transpose. i' = (i % l) * m + i / l
            int i_prime = (i % (*l_ptr)) * (*m_ptr) + i / (*l_ptr);
            int b_read = scanf("%d", &(*b_mat_ptr)[i_prime]);
            (void)b_read;
        }
    }

    MPI_Bcast(n_ptr, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(m_ptr, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(l_ptr, 1, MPI_INT, 0, MPI_COMM_WORLD);

    if (rank != 0) {
        *a_mat_ptr = (int *)malloc((*n_ptr) * (*m_ptr) * sizeof(int));
        *b_mat_ptr = (int *)malloc((*m_ptr) * (*l_ptr) * sizeof(int));
    }

    MPI_Bcast(*a_mat_ptr, (*n_ptr) * (*m_ptr), MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(*b_mat_ptr, (*m_ptr) * (*l_ptr), MPI_INT, 0, MPI_COMM_WORLD);
}

void matrix_multiply(const int n, const int m, const int l, const int *a_mat, const int *b_mat) {
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    int rows_per_process = n / size;
    int rows_residual = n % size;
    
    int *c_mat = NULL;
    //printf("rank %d: rows_per_process = %d\n", rank, rows_per_process);
    if (rows_residual == 0 || rank < size - 1) {
        c_mat = (int *)calloc(rows_per_process * l, sizeof(int));
    } else {
        c_mat = (int *)calloc((rows_per_process + rows_residual) * l, sizeof(int));
    }

    for (int i = 0; i < rows_per_process; i++) {
        for (int j = 0; j < l; j++) {
            for (int k = 0; k < m; k++) {
                // after transpose, we can align index on k
                c_mat[i * l + j] += a_mat[(i + rank * rows_per_process) * m + k] * b_mat[j * m + k];
                //c_mat[i * l + j] += a_mat[(i + rank * rows_per_process) * m + k] * b_mat[k * l + j];
            }
        }
    }
    
    int *result = NULL;
    if (rank == 0) {
        result = (int *)calloc(n * l, sizeof(int));
    }
    MPI_Gather(c_mat, rows_per_process * l, MPI_INT, result, rows_per_process * l, MPI_INT, 0, MPI_COMM_WORLD);
    // residual rows
    if (rows_residual > 0 && rank == size - 1) {
        for (int i = 0; i < rows_residual; i++) {
            for (int j = 0; j < l; j++) {
                for (int k = 0; k < m; k++) {
                    // after transpose, we can align index on k
                    c_mat[(rows_per_process + i) * l + j] += a_mat[(rows_per_process * size + i) * m + k] * b_mat[j * m + k];
                }
            }
        }
        MPI_Send(&c_mat[rows_per_process * l], rows_residual * l, MPI_INT, 0, 1, MPI_COMM_WORLD);
        // printf("== last process total cmat ==\n");
        // for (int y=0; y < (rows_per_process + rows_residual) * l; y++) {
        //     printf("%d ", c_mat[y]);
        // }
        // printf("\n");
        // printf("== residual ==\n");
        // for (int x= rows_per_process * l ; x < (rows_per_process + rows_residual) * l; x++) {
        //     printf("%d ", c_mat[x]);
        // }
        // printf("\n");
        // printf("rank %d: send residual %d rows\n", rank, rows_residual);
    }

    if (rank == 0) {
        if (n % size > 0) {
            // got to receive the residual rows before printing
            MPI_Recv(result + size * (n / size) * l, rows_residual * l, MPI_INT, size - 1, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            //printf("rank %d: receive residial %d rows, received from result[%d]\n", rank, rows_residual, (n - rows_residual) * l);
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < l; j++) {
                printf("%d ", result[i * l + j]);
            }
            printf("\n");
        }
        free(result);
    }

    free(c_mat);
}

void destruct_matrices(int *a_mat, int *b_mat) {
    free(a_mat);
    free(b_mat);
}
